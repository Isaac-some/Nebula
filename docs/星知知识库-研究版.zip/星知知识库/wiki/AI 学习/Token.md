---
title: Token
id: 0671bcf9-eecb-4488-adf0-9d7d9842d59f
collection: AI 学习
abstract: 模型处理文本的基本单位；它可能是一个字、词的一部分或标点。
overview: |-
  ## 核心理解

  人按句子阅读，语言模型通常按 token 接收和生成文本。分词方式取决于具体模型；中文和英文的字数与 token 数不能简单一比一换算。

  ## 需要掌握

  - 输入 token：当前请求中提供给模型的内容。
  - 输出 token：模型生成的内容。
  - 分词器：决定文本如何拆成 token。

  ## 学习边界

  不要把字符数量直接当作精确 token 数。
tags:
  - 基础层
prerequisites: []
aliases: []
status: 已掌握
favorite: false
source: 'https://platform.openai.com/tokenizer'
sources: []
noteType: concept
organizations: []
relations: []
---
## 从这里理解

人按句子阅读，语言模型通常按 token 接收和生成文本。分词方式取决于具体模型；中文和英文的字数与 token 数不能简单一比一换算。

## 拆开来看

### 01 · 输入 token

输入 token：当前请求中提供给模型的内容。

### 02 · 输出 token

输出 token：模型生成的内容。

### 03 · 分词器

分词器：决定文本如何拆成 token。

> 不要把字符数量直接当作精确 token 数。

## 把知识连起来

- [[上下文窗口]]
- [[提示词缓存]]

## 检查自己的理解

- 我能用自己的话解释“Token”吗？
- 我能给出一个真实的使用例子吗？
- 我知道它的局限，以及还需要补齐哪些知识吗？

## 延伸阅读

[官方资料 / 原始参考](https://platform.openai.com/tokenizer)

---

*这是一篇帮助体验学习流程的示例笔记，建议你在学习后用自己的理解改写。*
