---
title: AlphaCode 系列：生成候选、运行检查与最终评测
id: fc5947b8-d52f-4615-8f25-7cd17cc911f9
collection: 前沿研究
abstract: DeepMind 的代码研究展示模型生成与搜索筛选的配合，也说明单次答案、系统成绩和真实工作表现必须分开。
overview: 先生成多种代码候选，再依据执行行为过滤、聚类并选择提交。系统表现来自模型与搜索组合，不能直接代表一次调用的可靠性。
tags:
  - 方法层
  - 模型评测
  - 代码生成
  - 推理搜索
  - Google DeepMind
prerequisites:
  - 大语言模型
  - 模型评测
  - 工具调用
aliases:
  - AlphaCode
  - AlphaCode 2
  - 候选筛选
  - Codeforces
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2203.07814'
sources:
  - title: Competition-Level Code Generation with AlphaCode
    url: 'https://arxiv.org/abs/2203.07814'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2022-02-08'
  - title: AlphaCode 2 Technical Report
    url: >-
      https://storage.googleapis.com/deepmind-media/AlphaCode2/AlphaCode2_Tech_Report.pdf
    publisher: Google DeepMind
    publishedAt: '2023-12-06'
noteType: research
organizations:
  - Google DeepMind
relations:
  - target: 模型评测
    kind: explains
  - target: 工具调用
    kind: applies
  - target: 大语言模型
    kind: evaluates
  - target: 思维链与自洽性：从一条路径到多条候选
    kind: contrasts
---
## 要解决的问题

竞争编程不只要求把文字翻成代码，还要找到算法、处理约束并输出正确程序。AlphaCode 把经过清理的训练数据、大规模模型采样，以及基于程序行为的候选过滤组成系统，在模拟竞赛中评估排名。[S1](https://arxiv.org/abs/2203.07814)

## 机制与证据

AlphaCode 2 使用 Gemini 系列模型生成多样候选，再过滤、按行为聚类并排序选择，报告在指定 Codeforces 评测中解决更多问题。关键不是“第一个答案就正确”，而是把[[大语言模型]]视为候选生成器，用可执行检查与选择机制提高有限提交机会的利用率。[S2](https://storage.googleapis.com/deepmind-media/AlphaCode2/AlphaCode2_Tech_Report.pdf)

## 边界与学习连接

通过给定测试不等于对所有输入正确；大量采样和筛选的计算成本也必须计入。竞赛排名依赖题目集合与评测协议，不能直接推断软件工程中的维护性、需求理解或安全性。原版 AlphaCode 发表时来自 DeepMind，第二版报告明确署名 Google DeepMind，保留这一历史区别有助于追溯研究演进。

## 学习时如何读

关注候选数、可用测试、最终提交数与成本，而不只看百分位。将它连接[[模型评测]]与[[工具调用]]，可以理解外部执行器既是工作工具，也能提供反馈；再与[[思维链与自洽性：从一条路径到多条候选]]对比，一种聚合答案一致性，一种利用程序执行行为。两者都增加搜索，但验证信号不同，因此不能互换解释。

## 阅读练习

也可以比较同样预算下的一次强模型回答和多次候选筛选，把最终准确率、总调用量与验证成本放在一起观察。

## 原始来源

- [S1](https://arxiv.org/abs/2203.07814) · Competition-Level Code Generation with AlphaCode · DeepMind (now Google DeepMind) · 2022-02-08
- [S2](https://storage.googleapis.com/deepmind-media/AlphaCode2/AlphaCode2_Tech_Report.pdf) · AlphaCode 2 Technical Report · Google DeepMind · 2023-12-06
