---
title: 从人类偏好到指令遵循：RLHF 如何改变模型行为
id: 41a381de-88de-45dd-80ea-92158d0fe670
collection: 前沿研究
abstract: 通过摘要偏好学习与 InstructGPT，区分预测下一个词、遵循指令和事实正确这三个训练目标。
overview: 人类示范提供初始行为，成对偏好训练奖励模型，强化学习再优化输出策略。奖励只是对人类偏好的近似，需要评估偏差与泛化。
tags:
  - 模型层
  - 强化学习
  - RLHF
  - 指令微调
  - OpenAI
prerequisites:
  - 大语言模型
  - 强化学习
aliases:
  - InstructGPT
  - RLHF
  - 人类反馈强化学习
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2009.01325'
sources:
  - title: Learning to summarize from human feedback
    url: 'https://arxiv.org/abs/2009.01325'
    publisher: OpenAI
    publishedAt: '2020-09-02'
  - title: Aligning language models to follow instructions
    url: 'https://openai.com/index/instruction-following/'
    publisher: OpenAI
    publishedAt: '2022-01-27'
noteType: research
organizations:
  - OpenAI
relations:
  - target: 强化学习
    kind: explains
  - target: 大语言模型
    kind: extends
  - target: 提示词工程
    kind: contrasts
  - target: DeepSeek-R1 与 DeepSeekMath：奖励怎样塑造推理
    kind: contrasts
---
## 要解决的问题

预训练擅长预测文本，不代表能稳定遵循用户意图。OpenAI 的摘要研究还指出，参考摘要匹配指标只是质量的替代目标：词面相似未必意味着人更喜欢读。因此，需要把人类对输出的比较引入训练。[S1](https://arxiv.org/abs/2009.01325)

## 机制与证据

摘要研究先收集成对偏好，再训练奖励模型预测哪份摘要更好，用[[强化学习]]调整生成策略。InstructGPT 将类似方法扩展到 API 指令：收集理想回答示范、对候选回答排序、继续优化模型。其报告中，标注者在所测提示分布上更偏好较小的指令模型，而非大得多的基础 GPT-3；这支持“训练目标影响体验”，不能解读为小模型在所有能力上胜出。[S2](https://openai.com/index/instruction-following/)

## 边界与学习连接

奖励模型会继承标注者偏好与样本分布，优化它不能保证所有事实正确，也不等于找到唯一的人类价值标准。更好的文字风格甚至可能让错误更有说服力。学习时可以把[[大语言模型]]的预训练、对齐训练和[[提示词工程]]分成不同知识点：前两者改变参数，后者在推理时提供输入。继续阅读[[DeepSeek-R1 与 DeepSeekMath：奖励怎样塑造推理]]，比较人类偏好奖励与数学、代码中可检查的结果奖励，二者都属于训练信号设计。

## 阅读练习

阅读实验时，把预训练底座、示范数据、偏好标注、奖励模型与最终评价者分别列出。特别检查“更受偏好”指的是哪些人、哪些问题，以及是否同时测了事实性。沿这些问题做笔记，可以将“回答听起来好”与“回答可由证据支持”分开，再观察两类指标是否一起改善。

## 原始来源

- [S1](https://arxiv.org/abs/2009.01325) · Learning to summarize from human feedback · OpenAI · 2020-09-02
- [S2](https://openai.com/index/instruction-following/) · Aligning language models to follow instructions · OpenAI · 2022-01-27
