---
title: 从工作流到自主 Agent：何时值得增加复杂度
id: 80774963-ce73-4108-b0a3-a37fdd674696
collection: 前沿研究
abstract: 综合 Anthropic 的架构方法与研究系统实践，理解固定流程、动态决策和多 Agent 的取舍。
overview: 先分清任务路径能否预先确定，再决定使用单次调用、固定工作流或自主 Agent。多 Agent 的价值来自可并行探索，也需要付出协调与调用成本。
tags:
  - 应用层
  - AI Agent
  - 工作流
  - 多智能体
  - Anthropic
prerequisites:
  - AI Agent
  - 工作流
  - 工具调用
aliases:
  - Agent 架构
  - Multi-agent
  - Orchestrator workers
status: 未开始
favorite: false
source: 'https://www.anthropic.com/research/building-effective-agents'
sources:
  - title: Building effective agents
    url: 'https://www.anthropic.com/research/building-effective-agents'
    publisher: Anthropic
    publishedAt: '2024-12-19'
  - title: How we built our multi-agent research system
    url: 'https://www.anthropic.com/research/multi-agent-research-system'
    publisher: Anthropic
    publishedAt: '2025-06-13'
noteType: research
organizations:
  - Anthropic
relations:
  - target: AI Agent
    kind: explains
  - target: 工作流
    kind: contrasts
  - target: 上下文窗口
    kind: applies
  - target: 上下文工程：把有限窗口留给有用信息
    kind: extends
---
## 要解决的问题

看到 Agent 完成整项工作，很容易把效果归因于“更加自主”。真正需要判断的是：任务步骤能否提前写清、下一步是否依赖刚获得的信息，以及失败后如何发现。Anthropic 将预定义代码路径称为[[工作流]]，把模型动态决定步骤与[[工具调用]]的系统称为自主 [[AI Agent]]。[S1](https://www.anthropic.com/research/building-effective-agents)

## 机制与证据

固定任务可以串联、路由或并行执行；开放问题可以由协调者拆分子任务，再汇总结果。研究系统让多个 Agent 在独立[[上下文窗口]]里探索不同方向，从而扩大搜索覆盖。其内部研究评测中，多 Agent 配置优于单 Agent，但模型组合与资源投入也有变化，不能把收益全部归因于“人数更多”。[S2](https://www.anthropic.com/research/multi-agent-research-system)

## 边界与学习连接

这两篇是工程经验与内部评测，并非证明某种架构普遍最优。可独立分解的广度搜索更适合并行；强依赖、共享状态多的任务会增加协调成本。对个人知识库，先把检索、阅读、引用记录做稳定，再考虑自动探索。阅读[[上下文工程：把有限窗口留给有用信息]]可以理解为什么子任务需要独立上下文；阅读[[ReAct 与 WebAgent：让行动带回新证据]]可以看到自主循环的具体形式。

## 阅读练习

选一个自己要完成的任务，写出哪些步骤确定、哪些步骤需要等新信息，再分别标记失败的发现方式。若流程已经能够明确表达，就先尝试固定路径；若任务必须根据观察改向，再比较自主循环是否值得。把成功标准和停止条件写在方案旁边，能避免仅用演示效果判断架构。

## 原始来源

- [S1](https://www.anthropic.com/research/building-effective-agents) · Building effective agents · Anthropic · 2024-12-19
- [S2](https://www.anthropic.com/research/multi-agent-research-system) · How we built our multi-agent research system · Anthropic · 2025-06-13
