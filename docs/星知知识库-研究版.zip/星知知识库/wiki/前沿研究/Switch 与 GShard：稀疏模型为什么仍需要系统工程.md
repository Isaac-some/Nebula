---
title: Switch 与 GShard：稀疏模型为什么仍需要系统工程
id: 365cab47-fe2d-4937-a732-7fd4118f2bcf
collection: 前沿研究
abstract: 两项 Google 研究说明，专家稀疏激活可以扩充容量，但路由、分片、通信与稳定性共同决定实际效率。
overview: GShard 连接条件计算与自动分片，Switch 简化专家路由。总参数、激活计算量、通信与内存需要分别记录，不能混为一个成本数字。
tags:
  - 模型层
  - 混合专家模型
  - 专家路由
  - 并行训练
  - Google
prerequisites:
  - Transformer
  - 混合专家模型
  - Token
aliases:
  - Switch Transformer
  - GShard
  - Sparse MoE
  - 稀疏激活
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2006.16668'
sources:
  - title: >-
      GShard: Scaling Giant Models with Conditional Computation and Automatic
      Sharding
    url: 'https://arxiv.org/abs/2006.16668'
    publisher: Google
    publishedAt: '2020-06-30'
  - title: >-
      Switch Transformers: Scaling to Trillion Parameter Models with Simple and
      Efficient Sparsity
    url: 'https://arxiv.org/abs/2101.03961'
    publisher: Google
    publishedAt: '2021-01-11'
noteType: research
organizations:
  - Google
relations:
  - target: 混合专家模型
    kind: explains
  - target: Transformer
    kind: extends
  - target: 模型评测
    kind: evaluates
  - target: DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长
    kind: contrasts
  - target: DeepSeek-V3：专家负载均衡也是学习问题
    kind: contrasts
---
## 要解决的问题

让模型拥有更多参数，同时不让每个输入都使用全部参数，是[[混合专家模型]]的基本动机。GShard 把稀疏专家与自动分片结合，在跨设备训练中表达并行计算，并在多语言翻译上验证大规模模型。[S1](https://arxiv.org/abs/2006.16668)

## 机制与证据

路由器为每个 [[Token]]选择部分专家，专家可以理解成被选择执行的前馈子网络。Switch Transformer 进一步简化路由，在通信、计算和训练稳定性之间做取舍，并研究较低精度训练。它报告在给定模型与资源条件下提高预训练速度，同时把规模扩展到很大的参数容量。[S2](https://arxiv.org/abs/2101.03961)

## 边界与学习连接

稀疏计算不等于所有成本都按同样比例下降。权重存储、跨设备传输、路由开销和专家分布仍可能成为瓶颈；论文中的加速依赖其基线、训练目标和硬件设置，不能直接迁移成通用服务速度。两项工作发表时属于 Google；不能因为后来团队整合而把历史来源都改写成 Google DeepMind。

## 学习时如何读

可以把每个模型记成一组维度：总参数、激活参数、训练计算、内存、通信和任务表现。只比较“多少 B”会掩盖关键差异。继续阅读[[DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长]]，观察专家细分与共享设计；再读[[DeepSeek-V3：专家负载均衡也是学习问题]]，比较路由的优化目标。它们是对同一问题的不同处理，不表示后来的方案在所有条件下都占优。

## 阅读练习

阅读硬件结果时，应同时检查比较对象是否具有相同训练目标与资源预算，把不可直接比较的数字保留原始上下文。

## 原始来源

- [S1](https://arxiv.org/abs/2006.16668) · GShard: Scaling Giant Models with Conditional Computation and Automatic Sharding · Google · 2020-06-30
- [S2](https://arxiv.org/abs/2101.03961) · Switch Transformers: Scaling to Trillion Parameter Models with Simple and Efficient Sparsity · Google · 2021-01-11
