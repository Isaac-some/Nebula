---
title: ReAct 与 WebAgent：让行动带回新证据
id: a4b8db52-b823-4ee2-9080-2d9fe39b9854
collection: 前沿研究
abstract: 从推理与行动交替到网页任务模块化，理解 Agent 如何借助外部反馈继续规划，而不只生成一份计划。
overview: ReAct 让推理、行动和观察交替；WebAgent 把网页规划、相关内容提取与程序生成分工。环境反馈是连接语言模型和真实任务的重要环节。
tags:
  - 应用层
  - AI Agent
  - 工具调用
  - 网页自动化
  - Google
  - Google DeepMind
prerequisites:
  - AI Agent
  - 工具调用
  - 上下文窗口
aliases:
  - ReAct
  - Reason Act Observe
  - WebAgent
  - HTML-T5
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2210.03629'
sources:
  - title: 'ReAct: Synergizing Reasoning and Acting in Language Models'
    url: 'https://arxiv.org/abs/2210.03629'
    publisher: Princeton University / Google
    publishedAt: '2022-10-06'
  - title: >-
      A Real-World WebAgent with Planning, Long Context Understanding, and
      Program Synthesis
    url: 'https://arxiv.org/abs/2307.12856'
    publisher: Google DeepMind / University of Tokyo
    publishedAt: '2023-07-24'
noteType: research
organizations:
  - Google
  - Google DeepMind
relations:
  - target: AI Agent
    kind: explains
  - target: 工具调用
    kind: applies
  - target: 上下文工程
    kind: applies
  - target: 从工作流到自主 Agent：何时值得增加复杂度
    kind: extends
---
## 要解决的问题

只在文本中连续推理，可能把最初的错误不断放大；只生成行动，又可能缺少计划更新。ReAct 把推理轨迹与任务行动交替生成，让模型通过检索或环境操作获得新观察，再决定下一步。[S1](https://arxiv.org/abs/2210.03629)

## 机制与证据

在知识问答中，行动可以查询外部资料；在交互任务中，行动改变环境并返回反馈。ReAct 在问答、事实核查和交互基准中比较这类循环。WebAgent 进一步针对真实网页，把任务拆解、长 HTML 中的相关片段提取，以及程序生成组合起来，让专门模型与通用模型分工处理不同瓶颈。[S2](https://arxiv.org/abs/2307.12856)

## 边界与学习连接

结果依赖工具、任务与测试网站，不能推断任意网页自动化都可靠。页面改变、定位失败或反馈不清楚，都可能让循环走偏。ReAct 是 Princeton 与 Google 合作；WebAgent 包含 Google DeepMind 与东京大学作者，机构归属应按原始论文保留。把这两篇连接[[AI Agent]]、[[工具调用]]和[[上下文工程]]，能够区分“模型知道什么”和“它能从环境获得什么”。

## 学习时如何读

画出目标、行动、观察、状态更新四个环节，并检查失败发生在哪一步。对知识库，检索到新文章之后修改阅读方向就是一种直观类比；这只是帮助理解，不表示当前产品已经自动规划或执行研究。继续读[[从工作流到自主 Agent：何时值得增加复杂度]]，可以再判断是否真的需要自由循环，还是固定检索与阅读步骤已足够。

## 阅读练习

另外可以把每次行动的输入与观察写成一条轨迹；轨迹能够帮助回看失败位置，但本身还不等于对结果正确性的证明。

## 原始来源

- [S1](https://arxiv.org/abs/2210.03629) · ReAct: Synergizing Reasoning and Acting in Language Models · Princeton University / Google · 2022-10-06
- [S2](https://arxiv.org/abs/2307.12856) · A Real-World WebAgent with Planning, Long Context Understanding, and Program Synthesis · Google DeepMind / University of Tokyo · 2023-07-24
