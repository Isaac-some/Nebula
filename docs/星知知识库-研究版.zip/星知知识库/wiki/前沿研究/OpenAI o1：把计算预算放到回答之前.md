---
title: OpenAI o1：把计算预算放到回答之前
id: 8224c3e3-21ad-4b45-a55b-c366e51b1415
collection: 前沿研究
abstract: 结合 o1 研究说明与系统卡，理解训练时强化学习、推理时计算和能力评测为何必须一起看。
overview: 推理模型通过训练学习更有效的中间求解过程，并在回答前使用额外计算。能力提升需要与任务类型、预算和局限一起解释。
tags:
  - 模型层
  - 推理模型
  - 思维链
  - 模型评测
  - OpenAI
prerequisites:
  - 大语言模型
  - 强化学习
  - 思维链
aliases:
  - o1
  - Test-time compute
  - 推理时计算
status: 未开始
favorite: false
source: 'https://openai.com/index/learning-to-reason-with-llms/'
sources:
  - title: Learning to reason with LLMs
    url: 'https://openai.com/index/learning-to-reason-with-llms/'
    publisher: OpenAI
    publishedAt: '2024-09-12'
  - title: OpenAI o1 System Card
    url: 'https://openai.com/index/openai-o1-system-card/'
    publisher: OpenAI
noteType: research
organizations:
  - OpenAI
relations:
  - target: 推理模型
    kind: explains
  - target: 强化学习
    kind: applies
  - target: 模型评测
    kind: evaluates
  - target: 思维链与自洽性：从一条路径到多条候选
    kind: contrasts
---
## 要解决的问题

某些数学、代码与科学问题需要反复分解、检查和修正，直接生成第一个答案容易失败。o1 的研究说明把[[强化学习]]用于学习更有效的[[思维链]]，并报告训练计算与回答前的推理计算增加时，所测推理任务表现改善。[S1](https://openai.com/index/learning-to-reason-with-llms/)

## 机制与证据

这里有两个不同变量：训练时用奖励调整参数，推理时给单道题更多计算。前者改变模型，后者改变每次作答投入。文章比较了推理密集的考试和代码基准；配套系统卡则从幻觉、越狱、偏差与自主能力等方面评估模型，并记录训练后仍需研究的失败模式。[S2](https://openai.com/index/openai-o1-system-card/)

## 边界与学习连接

这不是“思考更久必然正确”的定律；难题、评测预算与抽样方式都会影响数字，也不能用一组考试成绩推断所有真实工作表现。可见的解释文本也不是内部推理真实性的保证。两份资料记录特定历史模型，不能作为当前 API 型号或价格说明。把[[推理模型]]与[[模型评测]]连接，可以提醒自己同时阅读能力结果、计算条件和限制；再与[[思维链与自洽性：从一条路径到多条候选]]对比，区分提示策略、多次采样与训练出推理行为。

## 阅读练习

可以选一组已有确定答案的问题，记录推理预算、响应时间和正确率，再加入一组日常写作任务做比较。不要预设所有任务都需要更多思考；通过同一评价标准观察代价和收益。这是理解论文的练习方案，真实效果仍由选定模型、数据和运行条件决定，不能用文章演示代替测量。

## 原始来源

- [S1](https://openai.com/index/learning-to-reason-with-llms/) · Learning to reason with LLMs · OpenAI · 2024-09-12
- [S2](https://openai.com/index/openai-o1-system-card/) · OpenAI o1 System Card · OpenAI
