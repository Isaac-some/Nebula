---
title: DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长
id: 9964feb0-c942-42dd-977e-43092e32daa6
collection: 前沿研究
abstract: 从专家细分、共享专家与 MLA 理解 DeepSeek 如何分别降低前馈计算和注意力缓存成本。
overview: MoE 用少量激活专家提供更大参数容量；MLA 压缩推理缓存。两者优化的是不同资源，不能仅用总参数量判断部署成本。
tags:
  - 模型层
  - 混合专家模型
  - 多头潜在注意力
  - DeepSeek
  - 推理效率
prerequisites:
  - Transformer
  - 注意力机制
  - 混合专家模型
aliases:
  - DeepSeek V2
  - DeepSeekMoE
  - MLA
  - MoE
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2401.06066'
sources:
  - title: >-
      DeepSeekMoE: Towards Ultimate Expert Specialization in Mixture-of-Experts
      Language Models
    url: 'https://arxiv.org/abs/2401.06066'
    publisher: DeepSeek
    publishedAt: '2024-01-11'
  - title: >-
      DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts
      Language Model
    url: 'https://arxiv.org/abs/2405.04434'
    publisher: DeepSeek
    publishedAt: '2024-05-07'
noteType: research
organizations:
  - DeepSeek
relations:
  - target: 混合专家模型
    kind: explains
  - target: 多头潜在注意力
    kind: explains
  - target: 记忆机制
    kind: contrasts
  - target: DeepSeek-V3：专家负载均衡也是学习问题
    kind: extends
---
## 要解决的问题

模型参数越多，训练、显存与推理成本通常越高，但这些成本不是同一个量。DeepSeekMoE 研究细分路由专家与隔离共享专家，让公共知识与专门化计算分工，减少专家之间的冗余。[S1](https://arxiv.org/abs/2401.06066)

## 机制与证据

[[混合专家模型]]每个[[Token]]只激活部分专家，因而总参数量与单次计算量可以分开。V2 同时采用 DeepSeekMoE 和[[多头潜在注意力]]：后者把注意力所需的键值缓存压缩成潜在表示。论文报告 V2 共 236B 参数、每个 Token 激活 21B，并在指定基线与测量条件下减少缓存和提高吞吐。这些结果分别对应参数容量、计算与存储三个维度。[S2](https://arxiv.org/abs/2405.04434)

## 边界与学习连接

不能把激活参数量直接当成实际显存需求，未激活的专家权重仍需存储或调度；路由、通信、批量大小与硬件也影响速度。缓存压缩改善长序列服务的资源压力，不代表自动具备更强的长期[[记忆机制]]。可与[[Switch 与 GShard：稀疏模型为什么仍需要系统工程]]对比专家路由，再沿[[DeepSeek-V3：专家负载均衡也是学习问题]]了解分配策略。这里的先后顺序是研究演进，不能当作学习 Agent 应用必须掌握的全部前置条件。

## 阅读练习

比较模型时，尝试为每个资源数字补上单位和测量条件：说的是权重、缓存、训练计算，还是生成吞吐。将硬件、序列长度与批量设置一起记录；若论文没有给出足够信息，就保留未知。这样可以避免把一种优化误读成所有成本同时下降，也能发现不同实验之间能否公平比较。

## 原始来源

- [S1](https://arxiv.org/abs/2401.06066) · DeepSeekMoE: Towards Ultimate Expert Specialization in Mixture-of-Experts Language Models · DeepSeek · 2024-01-11
- [S2](https://arxiv.org/abs/2405.04434) · DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts Language Model · DeepSeek · 2024-05-07
