---
title: Transformer 与 Universal Transformer：信息交互和重复计算
id: e27d0b19-7e38-4c77-9080-08955ce785f6
collection: 前沿研究
abstract: 把原始 Transformer 与 Universal Transformer 对照，理解注意力、位置表示以及跨深度重复计算的区别。
overview: 注意力决定信息如何交互，网络结构决定交互重复多少次。原始翻译结果不能直接推出通用推理能力，自适应计算也是独立研究问题。
tags:
  - 基础层
  - Transformer
  - 注意力机制
  - Google
  - Google DeepMind
prerequisites:
  - Token
  - 注意力机制
aliases:
  - Attention Is All You Need
  - Universal Transformer
  - 自注意力
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/1706.03762'
sources:
  - title: Attention Is All You Need
    url: 'https://arxiv.org/abs/1706.03762'
    publisher: Google (Google Brain / Google Research)
    publishedAt: '2017-06-12'
  - title: Universal Transformers
    url: 'https://arxiv.org/abs/1807.03819'
    publisher: Google Brain / DeepMind / University of Amsterdam
    publishedAt: '2018-07-10'
noteType: research
organizations:
  - Google
  - Google DeepMind
relations:
  - target: Transformer
    kind: explains
  - target: 注意力机制
    kind: explains
  - target: 上下文窗口
    kind: applies
  - target: 推理模型
    kind: contrasts
  - target: 残差连接与归一化：深层网络如何保持可训练
    kind: extends
---
## 要解决的问题

序列模型既要连接相隔很远的信息，也要有效利用并行硬件。原始 [[Transformer]] 用[[注意力机制]]替代序列上的循环与卷积，通过多头注意力、前馈网络与位置表示处理序列，在机器翻译任务中验证质量和训练效率。[S1](https://arxiv.org/abs/1706.03762)

## 机制与证据

注意力让一个位置按内容选择其他位置的信息；多头提供不同的表示子空间，位置编码补充次序。后续 Universal Transformer 则在深度方向重复应用共享变换，并研究按位置动态停止的机制，希望结合并行信息交互与循环计算的归纳偏置。论文在算法任务、语言建模和翻译等设置中比较了效果。[S2](https://arxiv.org/abs/1807.03819)

## 边界与学习连接

原始论文的直接证据主要来自翻译等特定任务，不能凭架构名称断言它已经理解所有领域。Universal Transformer 的理论计算能力依赖文中假设，也不代表实际模型总能完成任意程序。两者说明“读哪些信息”和“反复加工几次”可以分开研究。前者连接[[上下文窗口]]，后者可与[[推理模型]]形成概念对照，但不能说二者是同一种技术。

## 学习时如何读

先画出 Token 表示怎样进入注意力，再标出前馈网络与重复层；第二遍只比较两种模型是否共享参数、在哪里重复、怎样结束。这样可以把结构证据与训练规模、数据差异拆开。原始 Transformer 来自当时的 Google Brain / Google Research；Universal Transformer 包含 Google Brain、DeepMind 与大学作者，机构关系沿用论文发表时的归属。

## 阅读练习

进一步记录每次结构变化究竟改变信息路径、参数共享还是计算次数，避免把外观相似的流程误当作相同机制。

## 原始来源

- [S1](https://arxiv.org/abs/1706.03762) · Attention Is All You Need · Google (Google Brain / Google Research) · 2017-06-12
- [S2](https://arxiv.org/abs/1807.03819) · Universal Transformers · Google Brain / DeepMind / University of Amsterdam · 2018-07-10
