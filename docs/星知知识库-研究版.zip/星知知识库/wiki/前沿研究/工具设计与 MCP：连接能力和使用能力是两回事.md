---
title: 工具设计与 MCP：连接能力和使用能力是两回事
id: a24c5992-02bc-411e-8a03-b9930d2d0eb0
collection: 前沿研究
abstract: MCP 提供连接标准，工具设计决定模型能否选对工具并理解结果，两者解决不同层面的问题。
overview: 把工具描述、参数、结果内容和返回长度一起设计。协议建立连接，真实任务评测才能判断连接后是否完成工作。
tags:
  - 应用层
  - 工具调用
  - MCP
  - 接口设计
  - Anthropic
prerequisites:
  - 工具调用
  - MCP
aliases:
  - Model Context Protocol
  - Agent 工具设计
status: 未开始
favorite: false
source: 'https://www.anthropic.com/news/model-context-protocol'
sources:
  - title: Introducing the Model Context Protocol
    url: 'https://www.anthropic.com/news/model-context-protocol'
    publisher: Anthropic
    publishedAt: '2024-11-25'
  - title: Writing effective tools for agents — with agents
    url: 'https://www.anthropic.com/research/writing-tools-for-agents'
    publisher: Anthropic
    publishedAt: '2025-09-11'
noteType: research
organizations:
  - Anthropic
relations:
  - target: MCP
    kind: explains
  - target: 工具调用
    kind: applies
  - target: 模型评测
    kind: applies
  - target: 函数调用与结构化输出：格式正确之后还要验证什么
    kind: contrasts
---
## 要解决的问题

给模型接入很多接口后，它仍可能选错工具、误填参数，或被冗长返回淹没。[[MCP]] 的提出旨在用统一协议连接数据源与 AI 应用，减少每接一个系统就重做集成的成本；它并没有自动解决工具是否好用的问题。[S1](https://www.anthropic.com/news/model-context-protocol)

## 机制与证据

工具设计文章把接口看成确定性软件与不确定性 Agent 之间的契约，强调清楚的命名、功能边界、参数说明，以及与任务相关的返回信息。结果可以提供简洁或详细模式：摘要帮助快速判断，必要标识符支持后续[[工具调用]]。文章还提出用真实任务评测成功率与执行轨迹，而不能只检查接口返回了成功状态。[S2](https://www.anthropic.com/research/writing-tools-for-agents)

## 边界与学习连接

这属于工程方法，不表示任何遵循同一协议的工具都具有相同质量。工具能连接、参数格式正确、操作完成、用户目标达成，是需要分别验证的四件事。对本地知识库，未来若接入搜索工具，返回标题、简短命中理由和可追溯来源，比直接倾倒整库更有价值；具体设计仍要通过实际任务验证。可与[[函数调用与结构化输出：格式正确之后还要验证什么]]交叉阅读，理解协议、格式约束、事实验证之间的关系，并连接[[上下文工程]]与[[模型评测]]。

## 阅读练习

以知识库搜索为例，分别写清工具名称、查询参数、命中摘要、可打开的文档标识与无结果处理。再用几条含糊问题测试能否完成阅读任务，而不只验证接口能否调用。这个练习可以帮助发现工具契约的缺口，也能让协议连接与任务能力在图谱里保留各自的位置。

## 原始来源

- [S1](https://www.anthropic.com/news/model-context-protocol) · Introducing the Model Context Protocol · Anthropic · 2024-11-25
- [S2](https://www.anthropic.com/research/writing-tools-for-agents) · Writing effective tools for agents — with agents · Anthropic · 2025-09-11
