---
title: 从缩放定律到 Chinchilla：参数不是唯一的规模
id: 553b2d22-8154-4051-b1ec-933be075e61b
collection: 前沿研究
abstract: 对照 OpenAI 的经验缩放规律与 DeepMind 的算力最优研究，理解模型大小、训练数据和计算预算的共同约束。
overview: 缩放规律是对实验区域内关系的拟合。Chinchilla 将更多预算分配给训练 Token，提醒读者不要只按参数规模判断能力或效率。
tags:
  - 基础层
  - 缩放定律
  - 训练数据
  - 计算预算
  - OpenAI
  - Google DeepMind
prerequisites:
  - 大语言模型
  - Token
  - 缩放定律
aliases:
  - Chinchilla
  - Compute optimal
  - Scaling laws
  - 算力最优
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2001.08361'
sources:
  - title: Scaling Laws for Neural Language Models
    url: 'https://arxiv.org/abs/2001.08361'
    publisher: OpenAI
    publishedAt: '2020-01-23'
  - title: Training Compute-Optimal Large Language Models
    url: 'https://arxiv.org/abs/2203.15556'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2022-03-29'
noteType: research
organizations:
  - OpenAI
  - Google DeepMind
relations:
  - target: 缩放定律
    kind: explains
  - target: Token
    kind: applies
  - target: 模型评测
    kind: evaluates
  - target: OpenAI o1：把计算预算放到回答之前
    kind: contrasts
  - target: Switch 与 GShard：稀疏模型为什么仍需要系统工程
    kind: contrasts
---
## 要解决的问题

固定预算下，应该训练更大的模型，还是让较小模型读更多数据？OpenAI 的缩放研究观察交叉熵损失与参数、数据、训练计算之间的经验关系，并据此讨论计算分配。[S1](https://arxiv.org/abs/2001.08361)

## 机制与证据

DeepMind 的 Chinchilla 研究通过多组模型与训练 Token 组合重新估计预算分配，认为其研究范围内许多大模型训练数据不足。它用与 Gopher 相近的训练计算训练参数更小、数据更多的 Chinchilla，并在多项下游任务中验证效果。这说明“参数更多”不是固定算力下唯一值得增加的量。[S2](https://arxiv.org/abs/2203.15556)

## 边界与学习连接

[[缩放定律]]是受数据分布、训练配置和拟合范围影响的经验规律，不是对未来任意架构的物理定律。两篇文章也不是在完全相同设置中只改变一个变量。训练预算最优、推理服务成本最优和用户体验最优，并不天然一致；不能把某个 Token 与参数比例当成所有项目的固定公式。

## 学习时如何读

同时记录参数、训练 Token、数据来源、算力和[[模型评测]]条件，再判断研究优化的目标。将它与[[OpenAI o1：把计算预算放到回答之前]]连接，可以看到训练时投入和推理时投入之间还有另一条轴；与[[Switch 与 GShard：稀疏模型为什么仍需要系统工程]]连接，又能看到参数容量与激活计算的区别。这些横向关系让模型发展不再只是一条“越大越好”的时间线。

## 阅读练习

对于新的缩放结论，先找实验覆盖范围和拟合目标，再判断是否适用于自己关心的任务；图表之外的外推应保留为假设。

## 原始来源

- [S1](https://arxiv.org/abs/2001.08361) · Scaling Laws for Neural Language Models · OpenAI · 2020-01-23
- [S2](https://arxiv.org/abs/2203.15556) · Training Compute-Optimal Large Language Models · DeepMind (now Google DeepMind) · 2022-03-29
