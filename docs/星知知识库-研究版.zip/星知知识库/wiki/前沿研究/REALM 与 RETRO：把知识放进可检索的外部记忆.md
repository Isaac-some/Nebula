---
title: REALM 与 RETRO：把知识放进可检索的外部记忆
id: 775a186d-d72e-4849-bde6-47140e5a7778
collection: 前沿研究
abstract: 比较 Google 的 REALM 与 DeepMind 的 RETRO，理解检索不仅可以接在模型外，也可以参与训练和模型结构。
overview: REALM 研究联合学习知识检索，RETRO 用检索片段与分块交叉注意力增强生成。二者不能直接等同于“搜索几段文字再拼提示”的所有 RAG 系统。
tags:
  - 方法层
  - RAG
  - 向量检索
  - 记忆机制
  - Google
  - Google DeepMind
prerequisites:
  - RAG
  - 向量检索
  - 文档分块
aliases:
  - REALM
  - RETRO
  - Retrieval augmented pretraining
  - 检索增强预训练
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2002.08909'
sources:
  - title: 'REALM: Retrieval-Augmented Language Model Pre-Training'
    url: 'https://arxiv.org/abs/2002.08909'
    publisher: Google
    publishedAt: '2020-02-10'
  - title: Improving language models by retrieving from trillions of tokens
    url: 'https://arxiv.org/abs/2112.04426'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2021-12-08'
noteType: research
organizations:
  - Google
  - Google DeepMind
relations:
  - target: RAG
    kind: explains
  - target: 向量检索
    kind: applies
  - target: 记忆机制
    kind: extends
  - target: 文档分块
    kind: applies
  - target: 语义相似度
    kind: contrasts
---
## 要解决的问题

把知识全部存入参数，更新和追溯都不方便。REALM 在预训练中加入潜在知识检索器，通过语言建模信号学习从大文档库取回信息，并在开放域问答中验证效果。[S1](https://arxiv.org/abs/2002.08909)

## 机制与证据

RETRO 则按与前文的相似性检索语料片段，通过编码器和分块交叉[[注意力机制]]影响后续生成。其研究在大规模外部数据库上展示，检索增强可让较小参数模型在所测语言建模指标上达到大型参数模型的可比表现，并继续评估知识密集任务。[S2](https://arxiv.org/abs/2112.04426)

## 边界与学习连接

这两项工作把检索纳入训练或架构，不能把论文数字直接套到任意[[RAG]]应用。结果依赖检索语料、覆盖范围与评测条件；相似片段也可能过时、冲突或不支持答案。REALM 属于 Google，RETRO 发表时来自 DeepMind，这里按 Google DeepMind 的机构入口归档，同时保留历史名称。

## 学习时如何读

将检索系统拆成[[文档分块]]、[[向量嵌入]]、[[向量检索]]、信息使用与来源验证。对个人知识库，搜索命中解决的是“找到可能相关的文档”，引用核查解决的是“这篇文章是否支持这个说法”，两者需要不同判断。它们又能连接[[语义相似度]]、[[记忆机制]]与[[分层索引]]，让读者从应用层一路走到模型结构，而不把向量距离误当作事实可信度。

## 阅读练习

阅读延伸：同一个问题同时做关键词检索与语义检索，检查命中差异；再独立核查来源是否真正支持答案。这个练习能连接[[混合检索]]与证据判断，避免只因为搜索结果相关就认为它可信。

## 原始来源

- [S1](https://arxiv.org/abs/2002.08909) · REALM: Retrieval-Augmented Language Model Pre-Training · Google · 2020-02-10
- [S2](https://arxiv.org/abs/2112.04426) · Improving language models by retrieving from trillions of tokens · DeepMind (now Google DeepMind) · 2021-12-08
