---
title: DeepSeek-R1 与 DeepSeekMath：奖励怎样塑造推理
id: 4804caad-1956-4bd1-bc04-98eff629ee8f
collection: 前沿研究
abstract: 比较 DeepSeekMath 的 GRPO 与 R1 的训练流程，理解结果奖励、冷启动、蒸馏及其适用边界。
overview: 可检查答案为推理学习提供奖励信号。R1-Zero 与 R1 的训练流程不同，不能把前者的纯强化学习实验直接套到后者的完整产品模型。
tags:
  - 模型层
  - 强化学习
  - 推理模型
  - GRPO
  - DeepSeek
prerequisites:
  - 强化学习
  - 推理模型
  - 思维链
aliases:
  - DeepSeek R1
  - DeepSeekMath
  - GRPO
  - R1-Zero
  - 推理蒸馏
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2402.03300'
sources:
  - title: >-
      DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open
      Language Models
    url: 'https://arxiv.org/abs/2402.03300'
    publisher: DeepSeek
    publishedAt: '2024-02-05'
  - title: >-
      DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement
      Learning (v1)
    url: 'https://arxiv.org/html/2501.12948v1'
    publisher: DeepSeek
    publishedAt: '2025-01-22'
noteType: research
organizations:
  - DeepSeek
relations:
  - target: 强化学习
    kind: applies
  - target: 思维链
    kind: extends
  - target: 推理模型
    kind: explains
  - target: 从人类偏好到指令遵循：RLHF 如何改变模型行为
    kind: contrasts
  - target: OpenAI o1：把计算预算放到回答之前
    kind: contrasts
---
## 要解决的问题

如果每道复杂问题都要人工书写完整推理过程，训练数据成本很高。DeepSeekMath 将数学数据筛选与[[强化学习]]结合，并提出 GRPO：用一组候选回答的相对奖励估计改进方向，降低对独立价值模型的依赖。[S1](https://arxiv.org/abs/2402.03300)

## 机制与证据

R1 初版报告分别研究 R1-Zero 与 R1。前者直接在基础模型上进行强化学习，出现自我检查等行为，也暴露可读性与语言混杂问题；后者加入冷启动数据、拒绝采样与后续训练，兼顾推理和更广场景，并把大模型生成的数据用于小模型蒸馏。因此，“纯强化学习”描述的是特定实验路线，不能概括完整 R1 流程。[S2](https://arxiv.org/html/2501.12948v1)

## 边界与学习连接

数学、程序等可验证任务更容易设计结果奖励，开放研究、审美或真实经营任务往往没有同样清晰的判定器。生成了长[[思维链]]也不能保证结论正确；蒸馏的有效性同样依赖数据和底座。本文固定引用 2025 年初版，避免把后续修订与初始结论混在一起。关联[[从人类偏好到指令遵循：RLHF 如何改变模型行为]]，比较奖励来源；关联[[OpenAI o1：把计算预算放到回答之前]]，比较训练时强化学习与推理时预算，而不是仅按模型名称分类。

## 阅读练习

尝试给奖励信号分类：答案是否可直接检查、是否需要人类比较、是否只能让另一个模型打分。然后记录每种信号可能漏掉什么。这能帮助理解为什么数学与代码研究中的训练路线不能原样推广到开放任务，也能把奖励设计、结果验证和推理行为连成多条不同的知识关系。

## 原始来源

- [S1](https://arxiv.org/abs/2402.03300) · DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models · DeepSeek · 2024-02-05
- [S2](https://arxiv.org/html/2501.12948v1) · DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning (v1) · DeepSeek · 2025-01-22
