---
title: DeepSeek-V3：专家负载均衡也是学习问题
id: a479bb71-7546-42a7-be21-b967fe62b975
collection: 前沿研究
abstract: 把独立的无辅助损失均衡研究与 V3 技术报告连起来，理解路由质量、训练目标和系统效率的共同作用。
overview: 路由既要把 Token 分给合适专家，也要避免少数专家过载。动态偏置为负载调节提供途径，但整套模型收益不能归于单一技巧。
tags:
  - 模型层
  - 混合专家模型
  - 负载均衡
  - DeepSeek
  - 训练效率
prerequisites:
  - 混合专家模型
  - 多头潜在注意力
aliases:
  - DeepSeek V3
  - Loss-Free Balancing
  - 专家路由
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2408.15664'
sources:
  - title: Auxiliary-Loss-Free Load Balancing Strategy for Mixture-of-Experts
    url: 'https://arxiv.org/abs/2408.15664'
    publisher: DeepSeek / Peking University
    publishedAt: '2024-08-28'
  - title: DeepSeek-V3 Technical Report
    url: 'https://arxiv.org/abs/2412.19437'
    publisher: DeepSeek
    publishedAt: '2024-12-27'
noteType: research
organizations:
  - DeepSeek
relations:
  - target: 混合专家模型
    kind: extends
  - target: 多头潜在注意力
    kind: applies
  - target: 模型评测
    kind: evaluates
  - target: DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长
    kind: extends
---
## 要解决的问题

[[混合专家模型]]只激活少量专家，却可能出现部分专家过忙、其他专家空闲的问题。传统辅助损失鼓励均衡，但它产生的梯度也可能干扰语言建模目标。独立研究提出在选择专家前加入按近期负载更新的专家偏置，以调节分配。[S1](https://arxiv.org/abs/2408.15664)

## 机制与证据

该方法通过路由偏置影响专家选择，让负载控制不再完全依赖额外的训练梯度。论文在其规模与训练设置内比较了模型表现和负载均衡。V3 在更大的[[多头潜在注意力]]与 DeepSeekMoE 架构上采用这种策略，同时结合多 Token 预测和训练系统优化；报告模型总参数 671B、每个 Token 激活 37B。[S2](https://arxiv.org/abs/2412.19437)

## 边界与学习连接

“无辅助损失”是主要均衡策略的名称，不应推导成整个训练完全没有其他均衡约束。V3 是多项改动共同组成的系统，训练效率和基准结果不能全部归因于路由偏置。报告中的 GPU 时数也不代表完整研发预算，更不能直接类比个人电脑部署成本。沿[[DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长]]理解结构，再连接[[Token]]与[[模型评测]]，可以形成从模型机制到资源条件、再到任务证据的横向阅读路径。

## 阅读练习

沿来源阅读时，分别记录路由方法自身的对照实验和完整模型的综合结果；再标出哪些变化同时发生。对任何效率数字都追问基线、硬件与统计范围，而不要立刻换算成个人使用成本。这个练习能把机制解释和工程预算分开，使图谱里的“改进”关系保持可追溯的适用条件。

## 原始来源

- [S1](https://arxiv.org/abs/2408.15664) · Auxiliary-Loss-Free Load Balancing Strategy for Mixture-of-Experts · DeepSeek / Peking University · 2024-08-28
- [S2](https://arxiv.org/abs/2412.19437) · DeepSeek-V3 Technical Report · DeepSeek · 2024-12-27
