---
title: Google DeepMind
id: 0014a164-24d7-40a6-b804-d95d93850381
collection: 研究机构
abstract: 连接检索增强、计算资源分配、行动与代码评测等研究主题。
overview: |-
  本次选入 5 篇相关研究综述。

  相关主题：[[RAG]]、[[缩放定律]]、[[模型评测]]
tags:
  - 应用层
  - 研究机构
  - Google DeepMind
prerequisites: []
aliases:
  - DeepMind
  - 谷歌 DeepMind
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2307.12856'
sources:
  - title: >-
      A Real-World WebAgent with Planning, Long Context Understanding, and
      Program Synthesis
    url: 'https://arxiv.org/abs/2307.12856'
    publisher: Google DeepMind / University of Tokyo
    publishedAt: '2023-07-24'
  - title: Improving language models by retrieving from trillions of tokens
    url: 'https://arxiv.org/abs/2112.04426'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2021-12-08'
  - title: Training Compute-Optimal Large Language Models
    url: 'https://arxiv.org/abs/2203.15556'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2022-03-29'
  - title: Competition-Level Code Generation with AlphaCode
    url: 'https://arxiv.org/abs/2203.07814'
    publisher: DeepMind (now Google DeepMind)
    publishedAt: '2022-02-08'
  - title: AlphaCode 2 Technical Report
    url: >-
      https://storage.googleapis.com/deepmind-media/AlphaCode2/AlphaCode2_Tech_Report.pdf
    publisher: Google DeepMind
    publishedAt: '2023-12-06'
noteType: organization
organizations: []
relations: []
---
## 从一个研究主题进入

连接检索增强、计算资源分配、行动与代码评测等研究主题。这是一份基于本次选入文献的导航，不是该机构的完整研究目录。

## 本地已有的研究综述

- [[Transformer 与 Universal Transformer：信息交互和重复计算]]：把原始 Transformer 与 Universal Transformer 对照，理解注意力、位置表示以及跨深度重复计算的区别。
- [[ReAct 与 WebAgent：让行动带回新证据]]：从推理与行动交替到网页任务模块化，理解 Agent 如何借助外部反馈继续规划，而不只生成一份计划。
- [[REALM 与 RETRO：把知识放进可检索的外部记忆]]：比较 Google 的 REALM 与 DeepMind 的 RETRO，理解检索不仅可以接在模型外，也可以参与训练和模型结构。
- [[从缩放定律到 Chinchilla：参数不是唯一的规模]]：对照 OpenAI 的经验缩放规律与 DeepMind 的算力最优研究，理解模型大小、训练数据和计算预算的共同约束。
- [[AlphaCode 系列：生成候选、运行检查与最终评测]]：DeepMind 的代码研究展示模型生成与搜索筛选的配合，也说明单次答案、系统成绩和真实工作表现必须分开。

## 跨主题继续探索

[[RAG]]、[[缩放定律]]、[[模型评测]]。同一概念往往被多个机构从不同角度讨论，可以从概念页的反向链接继续阅读。

## 阅读方式

先读 L0 摘要判断是否相关，再读 L1 概览和 L2 细节。具体观点与实验条件以每篇综述列出的原始来源为准；机构归属按本次文献标注，不把所有结果归给现有的统一品牌。
