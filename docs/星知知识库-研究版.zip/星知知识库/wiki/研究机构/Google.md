---
title: Google
id: c4684c8f-0aaf-4650-b0e8-f293496ea459
collection: 研究机构
abstract: 从 Transformer 到稀疏专家、思维链与检索，追踪基础结构和方法的研究脉络。
overview: |-
  本次选入 6 篇相关研究综述。

  相关主题：[[Transformer]]、[[注意力机制]]、[[思维链]]
tags:
  - 应用层
  - 研究机构
  - Google
prerequisites: []
aliases:
  - 谷歌
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/1706.03762'
sources:
  - title: Attention Is All You Need
    url: 'https://arxiv.org/abs/1706.03762'
    publisher: Google (Google Brain / Google Research)
    publishedAt: '2017-06-12'
  - title: Universal Transformers
    url: 'https://arxiv.org/abs/1807.03819'
    publisher: Google Brain / DeepMind / University of Amsterdam
    publishedAt: '2018-07-10'
  - title: >-
      Exploring the Limits of Transfer Learning with a Unified Text-to-Text
      Transformer
    url: 'https://arxiv.org/html/1910.10683v4'
    publisher: Google
    publishedAt: '2019-10-23'
  - title: >-
      GShard: Scaling Giant Models with Conditional Computation and Automatic
      Sharding
    url: 'https://arxiv.org/abs/2006.16668'
    publisher: Google
    publishedAt: '2020-06-30'
  - title: >-
      Switch Transformers: Scaling to Trillion Parameter Models with Simple and
      Efficient Sparsity
    url: 'https://arxiv.org/abs/2101.03961'
    publisher: Google
    publishedAt: '2021-01-11'
  - title: Chain-of-Thought Prompting Elicits Reasoning in Large Language Models
    url: 'https://arxiv.org/abs/2201.11903'
    publisher: Google
    publishedAt: '2022-01-28'
noteType: organization
organizations: []
relations: []
---
## 从一个研究主题进入

从 Transformer 到稀疏专家、思维链与检索，追踪基础结构和方法的研究脉络。这是一份基于本次选入文献的导航，不是该机构的完整研究目录。

## 本地已有的研究综述

- [[Transformer 与 Universal Transformer：信息交互和重复计算]]：把原始 Transformer 与 Universal Transformer 对照，理解注意力、位置表示以及跨深度重复计算的区别。
- [[残差连接与归一化：深层网络如何保持可训练]]：从 ResNet 原始研究到 Transformer 与 T5，区分信息捷径、数值尺度和完整模型效果。
- [[Switch 与 GShard：稀疏模型为什么仍需要系统工程]]：两项 Google 研究说明，专家稀疏激活可以扩充容量，但路由、分片、通信与稳定性共同决定实际效率。
- [[思维链与自洽性：从一条路径到多条候选]]：Google 的两篇研究分别改变提示内容和解码策略，帮助区分展示中间步骤、采样多个答案与训练模型。
- [[ReAct 与 WebAgent：让行动带回新证据]]：从推理与行动交替到网页任务模块化，理解 Agent 如何借助外部反馈继续规划，而不只生成一份计划。
- [[REALM 与 RETRO：把知识放进可检索的外部记忆]]：比较 Google 的 REALM 与 DeepMind 的 RETRO，理解检索不仅可以接在模型外，也可以参与训练和模型结构。

## 跨主题继续探索

[[Transformer]]、[[注意力机制]]、[[思维链]]。同一概念往往被多个机构从不同角度讨论，可以从概念页的反向链接继续阅读。

## 阅读方式

先读 L0 摘要判断是否相关，再读 L1 概览和 L2 细节。具体观点与实验条件以每篇综述列出的原始来源为准；机构归属按本次文献标注，不把所有结果归给现有的统一品牌。
