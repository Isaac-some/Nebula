---
title: Anthropic
id: d881eabd-0965-4ea7-a206-5d516ce11c68
collection: 研究机构
abstract: 从 Agent 架构、工具设计与上下文管理，理解模型怎样组成可用的系统。
overview: |-
  本次选入 3 篇相关研究综述。

  相关主题：[[上下文工程]]、[[AI Agent]]、[[工具调用]]
tags:
  - 应用层
  - 研究机构
  - Anthropic
prerequisites: []
aliases: []
status: 未开始
favorite: false
source: 'https://www.anthropic.com/research/building-effective-agents'
sources:
  - title: Building effective agents
    url: 'https://www.anthropic.com/research/building-effective-agents'
    publisher: Anthropic
    publishedAt: '2024-12-19'
  - title: How we built our multi-agent research system
    url: 'https://www.anthropic.com/research/multi-agent-research-system'
    publisher: Anthropic
    publishedAt: '2025-06-13'
  - title: Effective context engineering for AI agents
    url: >-
      https://www.anthropic.com/research/effective-context-engineering-for-ai-agents
    publisher: Anthropic
    publishedAt: '2025-09-29'
  - title: >-
      The think tool: Enabling Claude to stop and think in complex tool use
      situations
    url: 'https://www.anthropic.com/research/claude-think-tool'
    publisher: Anthropic
    publishedAt: '2025-03-20'
  - title: Introducing the Model Context Protocol
    url: 'https://www.anthropic.com/news/model-context-protocol'
    publisher: Anthropic
    publishedAt: '2024-11-25'
  - title: Writing effective tools for agents — with agents
    url: 'https://www.anthropic.com/research/writing-tools-for-agents'
    publisher: Anthropic
    publishedAt: '2025-09-11'
noteType: organization
organizations: []
relations: []
---
## 从一个研究主题进入

从 Agent 架构、工具设计与上下文管理，理解模型怎样组成可用的系统。这是一份基于本次选入文献的导航，不是该机构的完整研究目录。

## 本地已有的研究综述

- [[从工作流到自主 Agent：何时值得增加复杂度]]：综合 Anthropic 的架构方法与研究系统实践，理解固定流程、动态决策和多 Agent 的取舍。
- [[上下文工程：把有限窗口留给有用信息]]：把系统指令、检索片段、工具返回和长期笔记作为一个整体管理，理解上下文工程的目标与边界。
- [[工具设计与 MCP：连接能力和使用能力是两回事]]：MCP 提供连接标准，工具设计决定模型能否选对工具并理解结果，两者解决不同层面的问题。

## 跨主题继续探索

[[上下文工程]]、[[AI Agent]]、[[工具调用]]。同一概念往往被多个机构从不同角度讨论，可以从概念页的反向链接继续阅读。

## 阅读方式

先读 L0 摘要判断是否相关，再读 L1 概览和 L2 细节。具体观点与实验条件以每篇综述列出的原始来源为准；机构归属按本次文献标注，不把所有结果归给现有的统一品牌。
