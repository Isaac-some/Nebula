---
title: DeepSeek
id: 94296477-cc14-401d-94e6-929fd65e9cb5
collection: 研究机构
abstract: 从 MoE、MLA 到推理强化学习，连接模型效率与能力训练。
overview: |-
  本次选入 3 篇相关研究综述。

  相关主题：[[混合专家模型]]、[[多头潜在注意力]]、[[强化学习]]
tags:
  - 应用层
  - 研究机构
  - DeepSeek
prerequisites: []
aliases:
  - 深度求索
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2401.06066'
sources:
  - title: >-
      DeepSeekMoE: Towards Ultimate Expert Specialization in Mixture-of-Experts
      Language Models
    url: 'https://arxiv.org/abs/2401.06066'
    publisher: DeepSeek
    publishedAt: '2024-01-11'
  - title: >-
      DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts
      Language Model
    url: 'https://arxiv.org/abs/2405.04434'
    publisher: DeepSeek
    publishedAt: '2024-05-07'
  - title: Auxiliary-Loss-Free Load Balancing Strategy for Mixture-of-Experts
    url: 'https://arxiv.org/abs/2408.15664'
    publisher: DeepSeek / Peking University
    publishedAt: '2024-08-28'
  - title: DeepSeek-V3 Technical Report
    url: 'https://arxiv.org/abs/2412.19437'
    publisher: DeepSeek
    publishedAt: '2024-12-27'
  - title: >-
      DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open
      Language Models
    url: 'https://arxiv.org/abs/2402.03300'
    publisher: DeepSeek
    publishedAt: '2024-02-05'
  - title: >-
      DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement
      Learning (v1)
    url: 'https://arxiv.org/html/2501.12948v1'
    publisher: DeepSeek
    publishedAt: '2025-01-22'
noteType: organization
organizations: []
relations: []
---
## 从一个研究主题进入

从 MoE、MLA 到推理强化学习，连接模型效率与能力训练。这是一份基于本次选入文献的导航，不是该机构的完整研究目录。

## 本地已有的研究综述

- [[DeepSeek-V2 与 DeepSeekMoE：容量和计算分开增长]]：从专家细分、共享专家与 MLA 理解 DeepSeek 如何分别降低前馈计算和注意力缓存成本。
- [[DeepSeek-V3：专家负载均衡也是学习问题]]：把独立的无辅助损失均衡研究与 V3 技术报告连起来，理解路由质量、训练目标和系统效率的共同作用。
- [[DeepSeek-R1 与 DeepSeekMath：奖励怎样塑造推理]]：比较 DeepSeekMath 的 GRPO 与 R1 的训练流程，理解结果奖励、冷启动、蒸馏及其适用边界。

## 跨主题继续探索

[[混合专家模型]]、[[多头潜在注意力]]、[[强化学习]]。同一概念往往被多个机构从不同角度讨论，可以从概念页的反向链接继续阅读。

## 阅读方式

先读 L0 摘要判断是否相关，再读 L1 概览和 L2 细节。具体观点与实验条件以每篇综述列出的原始来源为准；机构归属按本次文献标注，不把所有结果归给现有的统一品牌。
