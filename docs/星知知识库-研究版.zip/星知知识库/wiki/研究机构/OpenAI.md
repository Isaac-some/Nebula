---
title: OpenAI
id: dc22fd67-600a-4d44-9660-9e674027d917
collection: 研究机构
abstract: 从指令遵循、推理计算和结构化接口，理解训练、推理与应用的不同层次。
overview: |-
  本次选入 4 篇相关研究综述。

  相关主题：[[强化学习]]、[[推理模型]]、[[结构化输出]]
tags:
  - 应用层
  - 研究机构
  - OpenAI
prerequisites: []
aliases: []
status: 未开始
favorite: false
source: 'https://arxiv.org/abs/2009.01325'
sources:
  - title: Learning to summarize from human feedback
    url: 'https://arxiv.org/abs/2009.01325'
    publisher: OpenAI
    publishedAt: '2020-09-02'
  - title: Aligning language models to follow instructions
    url: 'https://openai.com/index/instruction-following/'
    publisher: OpenAI
    publishedAt: '2022-01-27'
  - title: Learning to reason with LLMs
    url: 'https://openai.com/index/learning-to-reason-with-llms/'
    publisher: OpenAI
    publishedAt: '2024-09-12'
  - title: OpenAI o1 System Card
    url: 'https://openai.com/index/openai-o1-system-card/'
    publisher: OpenAI
  - title: Function calling and other API updates
    url: 'https://openai.com/index/function-calling-and-other-api-updates/'
    publisher: OpenAI
    publishedAt: '2023-06-13'
  - title: Introducing Structured Outputs in the API
    url: 'https://openai.com/index/introducing-structured-outputs-in-the-api/'
    publisher: OpenAI
    publishedAt: '2024-08-06'
noteType: organization
organizations: []
relations: []
---
## 从一个研究主题进入

从指令遵循、推理计算和结构化接口，理解训练、推理与应用的不同层次。这是一份基于本次选入文献的导航，不是该机构的完整研究目录。

## 本地已有的研究综述

- [[从人类偏好到指令遵循：RLHF 如何改变模型行为]]：通过摘要偏好学习与 InstructGPT，区分预测下一个词、遵循指令和事实正确这三个训练目标。
- [[OpenAI o1：把计算预算放到回答之前]]：结合 o1 研究说明与系统卡，理解训练时强化学习、推理时计算和能力评测为何必须一起看。
- [[函数调用与结构化输出：格式正确之后还要验证什么]]：结合 OpenAI 两篇工程发布，理解函数参数生成、JSON Schema 约束与事实正确性的边界。
- [[从缩放定律到 Chinchilla：参数不是唯一的规模]]：对照 OpenAI 的经验缩放规律与 DeepMind 的算力最优研究，理解模型大小、训练数据和计算预算的共同约束。

## 跨主题继续探索

[[强化学习]]、[[推理模型]]、[[结构化输出]]。同一概念往往被多个机构从不同角度讨论，可以从概念页的反向链接继续阅读。

## 阅读方式

先读 L0 摘要判断是否相关，再读 L1 概览和 L2 细节。具体观点与实验条件以每篇综述列出的原始来源为准；机构归属按本次文献标注，不把所有结果归给现有的统一品牌。
