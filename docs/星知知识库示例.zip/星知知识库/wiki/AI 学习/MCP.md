---
title: MCP
id: c88672e0-2720-491e-9a0d-203291a1bc41
collection: AI 学习
abstract: 用于连接模型应用与外部工具、资源的开放协议。
overview: >-
  ## 核心理解


  Model Context Protocol
  为应用与外部能力提供统一的通信方式。应用作为客户端连接服务端，发现并使用服务端提供的能力。协议统一不代表权限自动可信。


  ## 需要掌握


  - 工具：可以执行的动作。

  - 资源：可以读取的数据。

  - 客户端与服务端：负责发现、通信与生命周期。


  ## 学习边界


  MCP 是连接协议，不是 Agent 的大脑，也不是安全授权的替代品。
tags:
  - 应用层
prerequisites:
  - 工具调用
aliases: []
status: 未开始
favorite: false
source: 'https://modelcontextprotocol.io/docs/getting-started/intro'
---
## 从这里理解

Model Context Protocol 为应用与外部能力提供统一的通信方式。应用作为客户端连接服务端，发现并使用服务端提供的能力。协议统一不代表权限自动可信。

## 拆开来看

### 01 · 工具

工具：可以执行的动作。

### 02 · 资源

资源：可以读取的数据。

### 03 · 客户端与服务端

客户端与服务端：负责发现、通信与生命周期。

> MCP 是连接协议，不是 Agent 的大脑，也不是安全授权的替代品。

## 把知识连起来

- [[AI Agent]]
- [[工作流]]

## 检查自己的理解

- 我能用自己的话解释“MCP”吗？
- 我能给出一个真实的使用例子吗？
- 我知道它的局限，以及还需要补齐哪些知识吗？

## 延伸阅读

[官方资料 / 原始参考](https://modelcontextprotocol.io/docs/getting-started/intro)

---

*这是一篇帮助体验学习流程的示例笔记，建议你在学习后用自己的理解改写。*
